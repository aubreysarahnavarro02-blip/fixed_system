"""
Management command: seed_data
Auto-generates 40 citizens, 10 sessions, ~200 attendance records for Brgy. San Jose.

Usage:
    python manage.py seed_data
    python manage.py seed_data --reset
"""

import random
import datetime
from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from django.utils import timezone
from attendance.models import UserProfile, Hall, Session, Citizen, AttendanceRecord, Announcement


FIRST_NAMES_M = [
    'Jose', 'Juan', 'Miguel', 'Carlos', 'Ramon', 'Eduardo', 'Roberto', 'Antonio',
    'Ricardo', 'Fernando', 'Emmanuel', 'Renato', 'Alfredo', 'Rolando', 'Benjamin',
    'Danilo', 'Gregorio', 'Hermogenes', 'Isidro', 'Juanito'
]
FIRST_NAMES_F = [
    'Maria', 'Ana', 'Rosario', 'Lourdes', 'Carmelita', 'Teresita', 'Natividad',
    'Esperanza', 'Consuelo', 'Milagros', 'Erlinda', 'Norma', 'Gloria', 'Felicidad',
    'Presentacion', 'Leticia', 'Marilou', 'Rowena', 'Shiela', 'Cristina'
]
LAST_NAMES = [
    'Santos', 'Reyes', 'Cruz', 'Bautista', 'Ocampo', 'Garcia', 'Dela Cruz',
    'Mendoza', 'Torres', 'Castillo', 'Ramos', 'Aquino', 'Villanueva', 'Gonzales',
    'Fernandez', 'Lopez', 'Perez', 'Pascual', 'Navarro', 'Soriano', 'Magbanua',
    'Galvez', 'Ilustre', 'Cabahug', 'Amores'
]
MIDDLE_NAMES = [
    'Dela Cruz', 'Santos', 'Reyes', 'Garcia', 'Torres', 'Lopez', 'Ramos',
    'Aquino', 'Cruz', 'Mendoza', 'Ocampo', 'Bautista', 'Castillo', 'Fernandez'
]
CATEGORIES = [
    ('official', 3), ('kagawad', 7), ('tanod', 5), ('resident', 15),
    ('sk', 3), ('senior', 4), ('pwd', 2), ('youth', 1),
]
SESSION_TYPES = [
    'regular', 'special', 'committee', 'assembly', 'seminar',
    'livelihood', 'health', 'emergency',
]
SESSION_TITLES = [
    'Regular Barangay Session — January',
    'Special Session on Livelihood Programs',
    'Barangay Assembly on Disaster Preparedness',
    'Committee Meeting on Peace and Order',
    'Seminar on Health and Sanitation',
    'Emergency Session — Typhoon Response',
    'Regular Barangay Session — February',
    'Livelihood Training Program',
    'Committee Meeting on Budget and Finance',
    'Regular Barangay Session — March',
]
HALLS = [
    {'name': 'Barangay Hall — Main Session Room', 'capacity': 100},
    {'name': 'Covered Court', 'capacity': 300},
    {'name': 'Barangay Health Center', 'capacity': 40},
    {'name': 'Multi-Purpose Hall', 'capacity': 150},
]
ANNOUNCEMENTS = [
    {
        'title': 'General Barangay Assembly — All Residents Invited',
        'content': 'All registered residents of Barangay San Jose are hereby invited to attend the General Barangay Assembly on the last Saturday of the month. Agenda includes budget review, peace and order updates, and livelihood programs.',
        'priority': 'high',
    },
    {
        'title': 'Barangay Health Center — Free Medical Mission',
        'content': 'The Barangay Health Center will be conducting a free medical mission this coming Friday. All residents, especially senior citizens and PWDs, are encouraged to avail of the free check-up, medicines, and consultations.',
        'priority': 'normal',
    },
    {
        'title': 'Barangay Clearance Processing — Updated Hours',
        'content': 'Processing of barangay clearances and certificates is now available Monday to Saturday, 8:00 AM to 5:00 PM. Bring valid ID and proof of residency.',
        'priority': 'normal',
    },
    {
        'title': 'URGENT: Flood Advisory — Brgy. San Jose',
        'content': 'Due to continuous rains, residents near the drainage area are advised to be on alert. The Barangay Disaster Risk Reduction and Management Council (BDRRMC) is on standby. Please evacuate immediately when signaled.',
        'priority': 'urgent',
    },
]


class Command(BaseCommand):
    help = 'Seeds the database with sample data for Barangay San Jose'

    def add_arguments(self, parser):
        parser.add_argument(
            '--reset',
            action='store_true',
            help='Clear all existing data before seeding',
        )

    def handle(self, *args, **options):
        if options['reset']:
            self.stdout.write('🗑  Clearing existing data...')
            AttendanceRecord.objects.all().delete()
            Session.objects.all().delete()
            Citizen.objects.all().delete()
            Hall.objects.all().delete()
            Announcement.objects.all().delete()
            User.objects.filter(is_superuser=False).delete()
            self.stdout.write(self.style.WARNING('   All data cleared.'))

        # ── Admin User ─────────────────────────────────────────────────────────
        if not User.objects.filter(username='admin').exists():
            admin = User.objects.create_superuser(
                username='admin',
                email='admin@sanjose.gov.ph',
                password='admin123',
                first_name='Barangay',
                last_name='Administrator',
            )
            admin.profile.role = 'admin'
            admin.profile.position = 'Barangay Administrator'
            admin.profile.save()
            self.stdout.write(self.style.SUCCESS('✅  Admin user created (username: admin / password: admin123)'))

        # ── Staff Users ────────────────────────────────────────────────────────
        staff_accounts = [
            ('secretary', 'Maria', 'Santos', 'secretary', 'Barangay Secretary'),
            ('kagawad1', 'Jose', 'Reyes', 'kagawad', 'Kagawad — Peace and Order'),
            ('staff1', 'Ana', 'Cruz', 'staff', 'Barangay Staff'),
        ]
        for uname, fname, lname, role, position in staff_accounts:
            if not User.objects.filter(username=uname).exists():
                u = User.objects.create_user(
                    username=uname, password='brgy2024',
                    first_name=fname, last_name=lname,
                    email=f'{uname}@sanjose.gov.ph'
                )
                u.profile.role = role
                u.profile.position = position
                u.profile.save()
        self.stdout.write(self.style.SUCCESS('✅  Staff accounts created (password: brgy2024)'))

        admin_user = User.objects.filter(is_superuser=True).first()

        # ── Halls ──────────────────────────────────────────────────────────────
        halls = []
        for h in HALLS:
            hall, _ = Hall.objects.get_or_create(
                name=h['name'],
                defaults={
                    'location': 'Brgy. San Jose, Surigao City',
                    'capacity': h['capacity'],
                    'status': 'available',
                }
            )
            halls.append(hall)
        self.stdout.write(self.style.SUCCESS(f'✅  {len(halls)} halls created'))

        # ── Citizens ───────────────────────────────────────────────────────────
        citizens = []
        random.seed(42)
        citizen_pool = []
        for cat, count in CATEGORIES:
            citizen_pool.extend([cat] * count)
        random.shuffle(citizen_pool)

        for i, category in enumerate(citizen_pool):
            gender = random.choice(['M', 'F'])
            first = random.choice(FIRST_NAMES_M if gender == 'M' else FIRST_NAMES_F)
            last = random.choice(LAST_NAMES)
            middle = random.choice(MIDDLE_NAMES)
            birth_year = random.randint(1950, 2005)
            birth_month = random.randint(1, 12)
            birth_day = random.randint(1, 28)
            contact = f'09{random.randint(100000000, 999999999)}'
            precinct = f'{random.randint(1, 8):02d}A'

            c, created = Citizen.objects.get_or_create(
                first_name=first,
                last_name=last,
                middle_name=middle,
                defaults={
                    'gender': gender,
                    'category': category,
                    'date_of_birth': datetime.date(birth_year, birth_month, birth_day),
                    'civil_status': random.choice(['single', 'married', 'widowed']),
                    'address': f'Purok {random.randint(1, 8)}, Brgy. San Jose, Surigao City',
                    'contact_number': contact,
                    'precinct_number': precinct,
                    'is_active': True,
                }
            )
            citizens.append(c)

        self.stdout.write(self.style.SUCCESS(f'✅  {len(citizens)} citizens created'))

        # ── Sessions ───────────────────────────────────────────────────────────
        sessions = []
        today = datetime.date.today()
        for i, title in enumerate(SESSION_TITLES):
            days_ago = (len(SESSION_TITLES) - i - 2) * 14
            s_date = today - datetime.timedelta(days=days_ago)
            status = 'completed' if days_ago > 7 else ('ongoing' if days_ago == 0 else 'scheduled')

            session, _ = Session.objects.get_or_create(
                title=title,
                defaults={
                    'session_type': SESSION_TYPES[i % len(SESSION_TYPES)],
                    'hall': random.choice(halls),
                    'date': s_date,
                    'start_time': datetime.time(9, 0),
                    'end_time': datetime.time(12, 0),
                    'status': status,
                    'presided_by': 'Hon. Punong Barangay',
                    'agenda': f'1. Call to order\n2. Roll call\n3. Approval of agenda\n4. Main business: {title}\n5. Open forum\n6. Adjournment',
                    'created_by': admin_user,
                }
            )
            sessions.append(session)

        self.stdout.write(self.style.SUCCESS(f'✅  {len(sessions)} sessions created'))

        # ── Attendance Records ─────────────────────────────────────────────────
        record_count = 0
        for session in sessions:
            if session.status not in ['completed', 'ongoing']:
                continue
            for citizen in citizens:
                # Weighted random: 70% present/late, 20% absent, 10% excused
                roll = random.random()
                if roll < 0.60:
                    status = 'present'
                elif roll < 0.75:
                    status = 'late'
                elif roll < 0.90:
                    status = 'absent'
                else:
                    status = 'excused'

                time_in = None
                time_out = None
                if status in ('present', 'late'):
                    hour = 9 if status == 'present' else random.randint(9, 10)
                    minute = random.randint(0, 30) if status == 'present' else random.randint(15, 59)
                    dt = datetime.datetime.combine(session.date, datetime.time(hour, minute))
                    time_in = timezone.make_aware(dt)
                    time_out = time_in + datetime.timedelta(hours=random.randint(2, 4))

                rec, created = AttendanceRecord.objects.get_or_create(
                    session=session,
                    citizen=citizen,
                    defaults={
                        'status': status,
                        'time_in': time_in,
                        'time_out': time_out,
                        'marked_by': admin_user,
                    }
                )
                if created:
                    record_count += 1

        self.stdout.write(self.style.SUCCESS(f'✅  {record_count} attendance records created'))

        # ── Announcements ──────────────────────────────────────────────────────
        for ann_data in ANNOUNCEMENTS:
            Announcement.objects.get_or_create(
                title=ann_data['title'],
                defaults={
                    'content': ann_data['content'],
                    'priority': ann_data['priority'],
                    'is_published': True,
                    'published_by': admin_user,
                }
            )
        self.stdout.write(self.style.SUCCESS(f'✅  {len(ANNOUNCEMENTS)} announcements created'))

        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS('=' * 60))
        self.stdout.write(self.style.SUCCESS('  SEEDING COMPLETE — Barangay Official Attendance Registry'))
        self.stdout.write(self.style.SUCCESS('=' * 60))
        self.stdout.write(f'  Citizens   : {Citizen.objects.count()}')
        self.stdout.write(f'  Sessions   : {Session.objects.count()}')
        self.stdout.write(f'  Records    : {AttendanceRecord.objects.count()}')
        self.stdout.write(f'  Halls      : {Hall.objects.count()}')
        self.stdout.write('')
        self.stdout.write('  Login Credentials:')
        self.stdout.write('  ┌─────────────┬──────────┬────────────┐')
        self.stdout.write('  │ Username    │ Password │ Role       │')
        self.stdout.write('  ├─────────────┼──────────┼────────────┤')
        self.stdout.write('  │ admin       │ admin123 │ Admin      │')
        self.stdout.write('  │ secretary   │ brgy2024 │ Secretary  │')
        self.stdout.write('  │ kagawad1    │ brgy2024 │ Kagawad    │')
        self.stdout.write('  │ staff1      │ brgy2024 │ Staff      │')
        self.stdout.write('  └─────────────┴──────────┴────────────┘')
        self.stdout.write(self.style.SUCCESS('=' * 60))
